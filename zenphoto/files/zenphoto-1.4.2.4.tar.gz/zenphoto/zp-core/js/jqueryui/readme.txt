************************************
*   Notes from Ozh - 06/jan/2009   *
************************************

jQuery UI files to get from http://ui.jquery.com/download :
- Select
	- Core
	- all Interaction components: Draggable, Droppable, Resizable, Selectable, Sortable
	- all widgits
	- the customized smoothness theme
